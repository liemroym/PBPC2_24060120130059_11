# PBPC2_24060120130059_10 

Nama: Liem, Roy Marcelino <br />
NIM: 24060120130059
